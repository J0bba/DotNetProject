## DotNetProject

The goal of the project is to reproduce a website that manage article, translations and stuff in .Net for our .Net course.