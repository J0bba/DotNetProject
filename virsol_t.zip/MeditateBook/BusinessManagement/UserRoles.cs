﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MeditateBook.BusinessManagement
{
    public class UserRoles
    {
        public enum Roles
        {
            User,
            Translator,
            Admin,
            Super_Admin
        }
    }
}